function val = doubleIntFunc(x,y)
    val = x^2 + y;
end

