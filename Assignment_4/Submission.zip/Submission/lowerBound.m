function y = lowerBound(x)
    % Function used to create handle for question 2
    y = x;
end

