function y = upperBound(x)
    % Function used to create handle for question 2
    y = 2*x^3;
end

