This README is simply to guide the grader to this submission.

1. The Assignment 2 report can be found in the root of this directory, under the name of 
"Bouchard_Tristan_443_A2.pdf"

2. The MATLAB Live-Script that I used to compute this assignment can be found under the root 
of this directory, under the name "Assignment2_260747124.mlx"

3. The Folder "./Functions/" contains the majority of the algorithms used to calculate the roots.
Please follow along the Live-Script file to understand which function is called where.