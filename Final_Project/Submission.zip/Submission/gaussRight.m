function [E] = gaussRight(r_)
    E = (12.4*10^-6)*(1/(2*pi*r_));
end

