function [funcVal] = intFunc3(theta,phi)
    r = 2;
    funcVal = ((12.4 * 10^(-6))/(2*pi*r))*(4)*sin(phi);
end

